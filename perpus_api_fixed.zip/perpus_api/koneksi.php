<?php
/**
 * koneksi.php
 * File koneksi database menggunakan PDO.
 * Semua halaman yang butuh database WAJIB include file ini.
 */

$DB_HOST = 'localhost';
$DB_NAME = 'perpus_api';
$DB_USER = 'root';
$DB_PASS = ''; // default XAMPP kosong

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    // Jangan tampilkan detail error database mentah ke user.
    http_response_code(500);
    die('Koneksi database gagal. Pastikan MySQL di XAMPP sudah aktif dan database "perpus_api" sudah dibuat.');
}
