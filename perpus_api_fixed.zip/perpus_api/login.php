
<?php
require 'auth.php';
require 'koneksi.php';

// Jika sudah login, langsung ke dashboard
if (!empty($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {

        $error = 'Username dan password wajib diisi.';

    } else {

        $stmt = $pdo->prepare(
            "SELECT id, username, password
             FROM admins
             WHERE username = ?"
        );

        $stmt->execute([$username]);

        $admin = $stmt->fetch();

        if (
            $admin &&
            password_verify($password, $admin['password'])
        ) {

            session_regenerate_id(true);

            $_SESSION['admin_id'] =
                $admin['id'];

            $_SESSION['admin_username'] =
                $admin['username'];

            header('Location: dashboard.php');

            exit;

        } else {

            $error = 'Username atau password salah.';

        }
    }
}
?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1">

<title>Login | Perpustakaan</title>

<?php include 'partials/theme-init.php'; ?>

<link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
>

<link
    rel="stylesheet"
    href="assets/css/style.css"
>


<style>

/* =========================================================
   LOGIN MODERN
   Menggunakan variable dari style.css
========================================================= */

.login-page {

    min-height: 100vh;

    display: flex;

    align-items: center;

    justify-content: center;

    padding: 30px;

    position: relative;

}


/* CONTAINER */

.login-container {

    width: 100%;

    max-width: 980px;

    min-height: 570px;

    display: grid;

    grid-template-columns: 1fr 1fr;

    background: var(--card-bg);

    border: 1px solid var(--border);

    border-radius: 24px;

    overflow: hidden;

    box-shadow: var(--glow);

}


/* =========================================================
   BRAND PANEL
========================================================= */

.login-brand {

    position: relative;

    padding: 55px;

    display: flex;

    flex-direction: column;

    justify-content: space-between;

    overflow: hidden;

    background:
        linear-gradient(
            145deg,
            rgba(14,122,84,.95),
            rgba(11,95,66,.98)
        );

    color: white;

}


/* DARK BRAND */

[data-bs-theme="dark"] .login-brand {

    background:
        radial-gradient(
            circle at 20% 20%,
            rgba(34,225,255,.22),
            transparent 40%
        ),

        radial-gradient(
            circle at 90% 80%,
            rgba(155,92,255,.25),
            transparent 45%
        ),

        linear-gradient(
            145deg,
            #15171c,
            #0f1014
        );

    border-right:
        1px solid rgba(34,225,255,.10);

}


/* DECORATION */

.login-brand::before {

    content: "";

    position: absolute;

    width: 300px;

    height: 300px;

    right: -120px;

    top: -100px;

    border-radius: 50%;

    border:
        1px solid rgba(255,255,255,.12);

    box-shadow:
        0 0 0 35px rgba(255,255,255,.025),
        0 0 0 70px rgba(255,255,255,.018);

}


.login-brand::after {

    content: "";

    position: absolute;

    width: 180px;

    height: 180px;

    left: -90px;

    bottom: -90px;

    border-radius: 50%;

    background:
        rgba(255,255,255,.06);

}


/* LOGO */

.library-logo {

    position: relative;

    z-index: 2;

    display: flex;

    align-items: center;

    gap: 12px;

}


.logo-icon {

    width: 45px;

    height: 45px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 14px;

    font-size: 22px;

    font-weight: 800;

    background:
        rgba(255,255,255,.13);

    border:
        1px solid rgba(255,255,255,.18);

    backdrop-filter: blur(10px);

}


.logo-text {

    display: flex;

    flex-direction: column;

}


.logo-name {

    font-family: var(--font-head);

    font-size: 18px;

    font-weight: 700;

}


.logo-subtitle {

    font-size: 10px;

    opacity: .7;

    letter-spacing: .12em;

    text-transform: uppercase;

}


/* HERO */

.login-brand-content {

    position: relative;

    z-index: 2;

}


.login-brand-content .eyebrow {

    font-size: 11px;

    font-weight: 700;

    letter-spacing: .18em;

    text-transform: uppercase;

    opacity: .65;

    margin-bottom: 14px;

}


.login-brand-content h1 {

    font-family: var(--font-head);

    font-size: 40px;

    line-height: 1.12;

    margin: 0 0 18px;

    letter-spacing: -.02em;

}


.login-brand-content p {

    max-width: 390px;

    margin: 0;

    line-height: 1.7;

    font-size: 14px;

    opacity: .78;

}


/* BOTTOM */

.login-brand-footer {

    position: relative;

    z-index: 2;

    font-size: 11px;

    opacity: .55;

}


/* =========================================================
   FORM PANEL
========================================================= */

.login-form-panel {

    padding: 55px;

    display: flex;

    align-items: center;

    background: var(--card-bg);

}


.login-form-inner {

    width: 100%;

    max-width: 390px;

    margin: auto;

}


/* FORM HEADER */

.login-form-header {

    margin-bottom: 30px;

}


.login-form-header h2 {

    font-family: var(--font-head);

    font-size: 29px;

    margin: 0 0 8px;

    color: var(--text);

}


.login-form-header p {

    margin: 0;

    font-size: 13px;

    color: var(--muted);

}


/* ERROR */

.login-modern-alert {

    padding: 11px 13px;

    margin-bottom: 20px;

    border-radius: 11px;

    font-size: 13px;

    color: #b3261e;

    background: #fdecea;

    border: 1px solid #f5c2c0;

}


[data-bs-theme="dark"] .login-modern-alert {

    color: #ffb4ab;

    background: rgba(229,72,77,.10);

    border-color: rgba(229,72,77,.25);

}


/* INPUT GROUP */

.login-field {

    margin-bottom: 19px;

}


.login-field label {

    display: block;

    margin-bottom: 7px;

    font-size: 12px;

    font-weight: 700;

    color: var(--muted);

    text-transform: uppercase;

    letter-spacing: .05em;

}


.login-input-wrap {

    position: relative;

}


.login-input-wrap input {

    width: 100%;

    height: 50px;

    padding:
        0 46px 0 15px;

    border-radius: 12px;

    border: 1px solid var(--border);

    background: var(--input-bg);

    color: var(--text);

    outline: none;

    font-size: 14px;

    transition:
        border-color .2s ease,
        box-shadow .2s ease;

}


.login-input-wrap input:focus {

    border-color: var(--accent);

    box-shadow: var(--focus-glow);

}


/* ICON */

.input-icon {

    position: absolute;

    right: 15px;

    top: 50%;

    transform: translateY(-50%);

    color: var(--muted);

    font-size: 17px;

    pointer-events: none;

}


/* SHOW PASSWORD */

.password-toggle {

    position: absolute;

    right: 13px;

    top: 50%;

    transform: translateY(-50%);

    border: none;

    background: transparent;

    color: var(--muted);

    cursor: pointer;

    padding: 5px;

    font-size: 13px;

}


.password-toggle:hover {

    color: var(--accent);

}


/* LOGIN BUTTON */

.login-submit {

    width: 100%;

    height: 51px;

    border: none;

    border-radius: 12px;

    margin-top: 8px;

    background: var(--accent);

    color: white;

    font-weight: 700;

    font-size: 14px;

    cursor: pointer;

    transition:
        transform .2s ease,
        box-shadow .2s ease,
        background .2s ease;

}


.login-submit:hover {

    transform: translateY(-2px);

    background: var(--accent-strong);

    box-shadow:
        0 10px 25px rgba(14,122,84,.25);

}


[data-bs-theme="dark"] .login-submit {

    background:
        linear-gradient(
            90deg,
            #12B8D4,
            #22E1FF
        );

    color: #0b1115;

}


[data-bs-theme="dark"] .login-submit:hover {

    box-shadow:
        0 0 25px rgba(34,225,255,.35);

}


/* DEMO ACCOUNT */

.login-demo {

    margin-top: 22px;

    padding: 12px 14px;

    border-radius: 11px;

    background: var(--surface-alt);

    border: 1px solid var(--border);

    font-size: 11px;

    color: var(--muted);

}


.login-demo strong {

    color: var(--text);

}


/* FOOTER */

.login-form-footer {

    text-align: center;

    margin-top: 24px;

    font-size: 11px;

    color: var(--muted);

}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 800px) {

    .login-container {

        grid-template-columns: 1fr;

        max-width: 500px;

        min-height: auto;

    }


    .login-brand {

        min-height: 280px;

        padding: 35px;

    }


    .login-brand-content h1 {

        font-size: 31px;

    }


    .login-form-panel {

        padding: 35px;

    }

}


@media (max-width: 480px) {

    .login-page {

        padding: 15px;

    }


    .login-brand {

        min-height: 250px;

        padding: 27px;

    }


    .login-brand-content h1 {

        font-size: 27px;

    }


    .login-form-panel {

        padding: 28px 22px;

    }

}

</style>

</head>


<body class="login-page">


<div class="login-container">


    <!-- =================================================
         BRAND
    ================================================== -->

    <section class="login-brand">


        <div class="library-logo">

            <div class="logo-icon">
                ▣
            </div>

            <div class="logo-text">

                <div class="logo-name">
                    Perpustakaan
                </div>

                <div class="logo-subtitle">
                    Digital Library
                </div>

            </div>

        </div>


        <div class="login-brand-content">

            <div class="eyebrow">
                Digital Library
            </div>

            <h1>
                Temukan dunia
                melalui buku.
            </h1>

            <p>
                Kelola koleksi, data buku, dan
                aktivitas perpustakaan melalui
                satu sistem yang sederhana dan
                modern.
            </p>

        </div>


        <div class="login-brand-footer">

            Sistem Informasi Perpustakaan
            &copy; <?= date('Y') ?>

        </div>


    </section>


    <!-- =================================================
         LOGIN FORM
    ================================================== -->

    <section class="login-form-panel">


        <div class="login-form-inner">


            <div class="login-form-header">

                <h2>
                    Selamat Datang
                </h2>

                <p>
                    Masuk ke panel administrasi
                    perpustakaan.
                </p>

            </div>


            <?php if ($error): ?>

                <div class="login-modern-alert">

                    <?= htmlspecialchars($error) ?>

                </div>

            <?php endif; ?>


            <form
                method="POST"
                action="login.php"
                autocomplete="off"
            >


                <!-- USERNAME -->

                <div class="login-field">

                    <label for="username">
                        Username
                    </label>

                    <div class="login-input-wrap">

                        <input
                            type="text"
                            id="username"
                            name="username"
                            placeholder="Masukkan username"
                            autocomplete="username"
                            required
                            autofocus
                        >

                        <span class="input-icon">
                            ◉
                        </span>

                    </div>

                </div>


                <!-- PASSWORD -->

                <div class="login-field">

                    <label for="password">
                        Password
                    </label>

                    <div class="login-input-wrap">

                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Masukkan password"
                            autocomplete="current-password"
                            required
                        >

                        <button
                            type="button"
                            class="password-toggle"
                            id="togglePassword"
                            aria-label="Tampilkan password"
                        >
                            Lihat
                        </button>

                    </div>

                </div>


                <!-- BUTTON -->

                <button
                    type="submit"
                    class="login-submit"
                >
                    Masuk ke Dashboard
                </button>


            </form>


            <!-- DEMO ACCOUNT -->

            <div class="login-demo">

                <strong>Akun ujian:</strong>
                admin / admin123

            </div>


            <div class="login-form-footer">

                Akses khusus administrator perpustakaan

            </div>


        </div>

    </section>

</div>


<script>

/*
|--------------------------------------------------------------------------
| SHOW / HIDE PASSWORD
|--------------------------------------------------------------------------
*/

const password =
    document.getElementById('password');

const togglePassword =
    document.getElementById('togglePassword');


togglePassword.addEventListener(
    'click',
    function () {

        const isPassword =
            password.type === 'password';


        password.type =
            isPassword
                ? 'text'
                : 'password';


        this.textContent =
            isPassword
                ? 'Sembunyikan'
                : 'Lihat';

    }
);

</script>


</body>

</html>