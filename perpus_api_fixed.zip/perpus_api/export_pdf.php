<?php
/**
 * export_pdf.php
 * Laporan PDF data buku TANPA library tambahan.
 * Teknik: halaman HTML rapi dengan CSS khusus cetak (@media print),
 * lalu otomatis membuka dialog "Print" browser -> pilih
 * "Save as PDF" -> simpan sebagai laporan_data_buku.pdf.
 *
 * Mendukung filter (GET params), sehingga bisa dipakai untuk
 * "Cetak Laporan berdasarkan Kategori" maupun laporan hasil pencarian:
 *   q         cari kode/judul/penulis/kategori
 *   kategori  cetak laporan khusus 1 kategori saja
 *   sort      tahun_asc | tahun_desc
 *
 * Ingin PDF asli langsung ter-download tanpa dialog print?
 * Lihat catatan Dompdf di GUIDE.md bagian "Upgrade Export".
 */

require 'auth.php';
require_login();
require 'koneksi.php';
require 'includes/book_filter.php';

$q        = trim($_GET['q'] ?? '');
$kategori = trim($_GET['kategori'] ?? '');
$sort     = $_GET['sort'] ?? '';

[$sql, $params] = build_book_filter($q, $kategori, $sort);
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

$tanggal = date('d F Y');

$judulLaporan = 'LAPORAN DATA BUKU PERPUSTAKAAN';
if ($kategori !== '') {
    $judulLaporan = 'LAPORAN DATA BUKU — KATEGORI: ' . mb_strtoupper($kategori);
}

$subJudulExtra = [];
if ($q !== '') $subJudulExtra[] = 'kata kunci "' . htmlspecialchars($q) . '"';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($judulLaporan) ?></title>
<style>
  body { font-family: Arial, sans-serif; color: #1f2430; margin: 2rem; }
  h1 { text-align: center; font-size: 1.3rem; margin-bottom: 0.2rem; }
  .subtitle { text-align: center; color: #6b7280; font-size: 0.85rem; margin-bottom: 1.5rem; }
  table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
  th, td { border: 1px solid #999; padding: 0.4rem 0.6rem; text-align: left; }
  th { background: #eef0f6; }
  .no-print { text-align: center; margin-bottom: 1.5rem; }
  .no-print button {
    padding: 0.6rem 1.2rem; background: #4f6df5; color: #fff;
    border: none; border-radius: 6px; cursor: pointer; font-size: 0.9rem;
  }
  @media print {
    .no-print { display: none; }
    body { margin: 0.5rem; }
  }
</style>
</head>
<body>

  <div class="no-print">
    <button onclick="window.print()">🖨️ Cetak / Simpan sebagai PDF</button>
    <p style="color:#6b7280; font-size:0.85rem;">
      Saat dialog cetak muncul, pilih tujuan <strong>"Save as PDF"</strong>,
      lalu simpan dengan nama <strong>laporan_data_buku.pdf</strong>.
    </p>
  </div>

  <h1><?= htmlspecialchars($judulLaporan) ?></h1>
  <p class="subtitle">
    Dicetak pada <?= $tanggal ?> — Total <?= count($books) ?> buku
    <?php if (!empty($subJudulExtra)): ?>
      — Filter: <?= implode(', ', $subJudulExtra) ?>
    <?php endif; ?>
  </p>

  <table>
    <thead>
      <tr>
        <th>No</th><th>Kode</th><th>Judul</th><th>Penulis</th>
        <th>Kategori</th><th>Tahun</th><th>Penerbit</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($books as $i => $b): ?>
        <tr>
          <td><?= $i + 1 ?></td>
          <td><?= htmlspecialchars($b['kode_buku']) ?></td>
          <td><?= htmlspecialchars($b['judul']) ?></td>
          <td><?= htmlspecialchars($b['penulis']) ?></td>
          <td><?= htmlspecialchars($b['kategori']) ?></td>
          <td><?= htmlspecialchars($b['tahun_terbit']) ?></td>
          <td><?= htmlspecialchars($b['penerbit']) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($books)): ?>
        <tr><td colspan="7" style="text-align:center; color:#6b7280;">Tidak ada data yang cocok dengan filter.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>

</body>
</html>
