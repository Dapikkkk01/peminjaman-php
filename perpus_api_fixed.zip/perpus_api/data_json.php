<?php
/**
 * data_json.php
 * Endpoint API JSON untuk data buku.
 * GET params opsional:
 *   q         cari (kode/judul/penulis/kategori)
 *   kategori  filter kategori
 *   sort      tahun_asc | tahun_desc
 *   page      halaman aktif (default 1)
 *   per_page  jumlah baris per halaman (default 5)
 */

require 'auth.php';
require_login(); // API ini butuh sesi admin (dipanggil dari halaman yang sudah login)

header('Content-Type: application/json; charset=utf-8');

require 'koneksi.php';
require 'includes/book_filter.php';

try {
    $q        = trim($_GET['q'] ?? '');
    $kategori = trim($_GET['kategori'] ?? '');
    $sort     = $_GET['sort'] ?? '';

    $page     = max(1, (int)($_GET['page'] ?? 1));
    $perPage  = (int)($_GET['per_page'] ?? 5);
    if ($perPage < 1)  $perPage = 5;
    if ($perPage > 50) $perPage = 50;

    [$baseSql, $params] = build_book_filter($q, $kategori, $sort);

    // Total baris (untuk hitung jumlah halaman) — ambil dari query yang sama tanpa ORDER BY/LIMIT
    $countSql = preg_replace('/ORDER BY.*$/i', '', $baseSql);
    $countSql = str_replace(
        'SELECT id, kode_buku, judul, penulis, kategori, tahun_terbit, penerbit, sampul FROM books',
        'SELECT COUNT(*) FROM books',
        $countSql
    );
    $countStmt = $pdo->prepare($countSql);
    $countStmt->execute($params);
    $totalData  = (int)$countStmt->fetchColumn();
    $totalPages = max(1, (int)ceil($totalData / $perPage));
    if ($page > $totalPages) $page = $totalPages;
    $offset = ($page - 1) * $perPage;

    $sql = $baseSql . " LIMIT :limit OFFSET :offset";
    $stmt = $pdo->prepare($sql);
    foreach ($params as $key => $val) {
        $stmt->bindValue($key, $val);
    }
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $data = $stmt->fetchAll();

    echo json_encode([
        'success'     => true,
        'data'        => $data,
        'pagination'  => [
            'page'        => $page,
            'per_page'    => $perPage,
            'total_data'  => $totalData,
            'total_pages' => $totalPages,
        ],
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Gagal mengambil data buku.',
    ]);
}
