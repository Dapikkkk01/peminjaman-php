<?php
/**
 * simpan_buku.php
 * Endpoint AJAX (dipanggil dari modal form di data_buku.php) untuk
 * menambah ATAU mengubah data buku, termasuk unggah foto sampul.
 * - Jika field "id" kosong/0  -> INSERT (tambah)
 * - Jika field "id" > 0       -> UPDATE (edit)
 * Selalu mengembalikan JSON: { success, message, errors? , data? }
 */

require 'auth.php';
require_login();
header('Content-Type: application/json; charset=utf-8');
require 'koneksi.php';

function json_fail(string $message, array $errors = []): void
{
    echo json_encode(['success' => false, 'message' => $message, 'errors' => $errors]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_fail('Metode tidak diizinkan.');
}

$id = (int)($_POST['id'] ?? 0);

$old = [
    'kode_buku'    => trim($_POST['kode_buku'] ?? ''),
    'judul'        => trim($_POST['judul'] ?? ''),
    'penulis'      => trim($_POST['penulis'] ?? ''),
    'kategori'     => trim($_POST['kategori'] ?? ''),
    'tahun_terbit' => trim($_POST['tahun_terbit'] ?? ''),
    'penerbit'     => trim($_POST['penerbit'] ?? ''),
];

// ---------- VALIDASI INPUT TEKS ----------
$errors = [];
foreach ($old as $key => $val) {
    if ($val === '') {
        $errors[$key] = 'Wajib diisi.';
    }
}

if ($old['tahun_terbit'] !== '' && (!ctype_digit($old['tahun_terbit'])
    || (int)$old['tahun_terbit'] < 1900
    || (int)$old['tahun_terbit'] > (int)date('Y') + 1)) {
    $errors['tahun_terbit'] = 'Tahun terbit tidak valid.';
}

if (empty($errors)) {
    $cekSql = "SELECT id FROM books WHERE kode_buku = ?" . ($id > 0 ? " AND id != ?" : "");
    $cekParams = $id > 0 ? [$old['kode_buku'], $id] : [$old['kode_buku']];
    $cek = $pdo->prepare($cekSql);
    $cek->execute($cekParams);
    if ($cek->fetch()) {
        $errors['kode_buku'] = 'Kode buku sudah digunakan.';
    }
}

if (!empty($errors)) {
    json_fail('Periksa kembali data yang diisi.', $errors);
}

// ---------- UPLOAD FOTO SAMPUL (opsional) ----------
$sampulPath = null; // null = tidak ada perubahan foto (khusus mode edit)
$uploadDir  = __DIR__ . '/assets/img/covers/';

if (isset($_FILES['sampul']) && $_FILES['sampul']['error'] !== UPLOAD_ERR_NO_FILE) {
    $file = $_FILES['sampul'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        json_fail('Gagal mengunggah foto sampul.');
    }

    $allowedExt = ['jpg', 'jpeg', 'png', 'webp'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, $allowedExt, true)) {
        json_fail('Format foto sampul harus JPG, PNG, atau WEBP.');
    }

    if ($file['size'] > 2 * 1024 * 1024) { // 2 MB
        json_fail('Ukuran foto sampul maksimal 2MB.');
    }

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $fileName = 'cover_' . uniqid() . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $uploadDir . $fileName)) {
        json_fail('Gagal menyimpan file foto sampul di server.');
    }

    $sampulPath = 'assets/img/covers/' . $fileName;
}

try {
    if ($id > 0) {
        // ---------- UPDATE ----------
        $stmt = $pdo->prepare("SELECT sampul FROM books WHERE id = ?");
        $stmt->execute([$id]);
        $existing = $stmt->fetch();
        if (!$existing) {
            json_fail('Data buku tidak ditemukan.');
        }

        $finalSampul = $sampulPath ?? $existing['sampul'];

        $upd = $pdo->prepare(
            "UPDATE books SET kode_buku=?, judul=?, penulis=?, kategori=?, tahun_terbit=?, penerbit=?, sampul=? WHERE id=?"
        );
        $upd->execute([
            $old['kode_buku'], $old['judul'], $old['penulis'],
            $old['kategori'], $old['tahun_terbit'], $old['penerbit'], $finalSampul, $id,
        ]);

        // Hapus file foto lama jika diganti dengan yang baru
        if ($sampulPath && !empty($existing['sampul']) && file_exists(__DIR__ . '/' . $existing['sampul'])) {
            @unlink(__DIR__ . '/' . $existing['sampul']);
        }

        echo json_encode(['success' => true, 'message' => 'Data buku berhasil diperbarui.']);
    } else {
        // ---------- INSERT ----------
        $ins = $pdo->prepare(
            "INSERT INTO books (kode_buku, judul, penulis, kategori, tahun_terbit, penerbit, sampul)
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        $ins->execute([
            $old['kode_buku'], $old['judul'], $old['penulis'],
            $old['kategori'], $old['tahun_terbit'], $old['penerbit'], $sampulPath,
        ]);

        echo json_encode(['success' => true, 'message' => 'Data buku berhasil ditambahkan.']);
    }
} catch (Throwable $e) {
    json_fail('Gagal menyimpan data buku.');
}
