const tabelBuku       = document.getElementById('tabelBuku');
const searchInput     = document.getElementById('searchInput');
const kategoriFilter  = document.getElementById('kategoriFilter');
const sortFilter      = document.getElementById('sortFilter');
const perPageFilter   = document.getElementById('perPageFilter');
const paginationBuku  = document.getElementById('paginationBuku');
const btnExportExcel  = document.getElementById('btnExportExcel');
const btnExportPdf    = document.getElementById('btnExportPdf');

const NO_COVER_IMG =
  'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="60" height="80">' +
    '<rect width="60" height="80" fill="#e5e7eb"/>' +
    '<text x="30" y="44" font-size="9" text-anchor="middle" fill="#9ca3af" font-family="sans-serif">No Cover</text>' +
    '</svg>'
  );

let debounceTimer  = null;
let currentPage    = 1;

function getFilters() {
  return {
    q:        searchInput ? searchInput.value.trim() : '',
    kategori: kategoriFilter ? kategoriFilter.value : '',
    sort:     sortFilter ? sortFilter.value : '',
    per_page: perPageFilter ? perPageFilter.value : '5',
  };
}

function buildUrl(base, extra) {
  const f = getFilters();
  const params = new URLSearchParams();
  if (f.q !== '')        params.set('q', f.q);
  if (f.kategori !== '') params.set('kategori', f.kategori);
  if (f.sort !== '')     params.set('sort', f.sort);
  Object.entries(extra || {}).forEach(([k, v]) => params.set(k, v));
  return base + '?' + params.toString();
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

function updateExportLinks() {
  if (btnExportExcel) btnExportExcel.href = buildUrl('export_excel.php');
  if (btnExportPdf)   btnExportPdf.href   = buildUrl('export_pdf.php');
}

async function loadData() {
  tabelBuku.innerHTML = '<tr><td colspan="9" class="loading-state">Memuat data...</td></tr>';
  updateExportLinks();

  try {
    const url = buildUrl('data_json.php', { page: currentPage, per_page: getFilters().per_page });
    const res = await fetch(url);
    if (!res.ok) throw new Error('Response tidak OK');

    const result = await res.json();
    if (!result.success) throw new Error(result.message || 'Gagal memuat data');

    renderTable(result.data, result.pagination);
    renderPagination(result.pagination);
  } catch (err) {
    tabelBuku.innerHTML = `<tr><td colspan="9" class="empty-state">Gagal memuat data. Periksa koneksi atau server. (${escapeHtml(err.message)})</td></tr>`;
    paginationBuku && (paginationBuku.innerHTML = '');
  }
}

function renderTable(data, pagination) {
  if (!data || data.length === 0) {
    tabelBuku.innerHTML = '<tr><td colspan="9" class="empty-state">Belum ada data buku.</td></tr>';
    return;
  }

  const startNo = pagination ? (pagination.page - 1) * pagination.per_page : 0;

  tabelBuku.innerHTML = data.map((buku, index) => `
    <tr>
      <td>${startNo + index + 1}</td>
      <td><img class="cover-thumb" src="${buku.sampul ? escapeHtml(buku.sampul) : NO_COVER_IMG}" alt="Sampul ${escapeHtml(buku.judul)}"></td>
      <td>${escapeHtml(buku.kode_buku)}</td>
      <td>${escapeHtml(buku.judul)}</td>
      <td>${escapeHtml(buku.penulis)}</td>
      <td><span class="badge">${escapeHtml(buku.kategori)}</span></td>
      <td>${escapeHtml(buku.tahun_terbit)}</td>
      <td>${escapeHtml(buku.penerbit)}</td>
      <td class="actions-cell">
        <button class="btn btn-secondary btn-sm" onclick="bukaModalEdit(${buku.id})">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="hapusBuku(${buku.id})">Hapus</button>
      </td>
    </tr>
  `).join('');
}

function renderPagination(pagination) {
  if (!paginationBuku || !pagination) return;
  const { page, total_pages } = pagination;
  currentPage = page;

  if (total_pages <= 1) {
    paginationBuku.innerHTML = '';
    return;
  }

  let html = '';
  html += pageItem(page - 1, '&laquo;', page === 1);
  for (let p = 1; p <= total_pages; p++) {
    html += pageItem(p, p, false, p === page);
  }
  html += pageItem(page + 1, '&raquo;', page === total_pages);

  paginationBuku.innerHTML = html;
}

function pageItem(targetPage, label, disabled, active) {
  return `<li class="page-item ${disabled ? 'disabled' : ''} ${active ? 'active' : ''}">
    <a class="page-link" href="#" onclick="event.preventDefault(); if(!${disabled}) gotoPage(${targetPage});">${label}</a>
  </li>`;
}

function gotoPage(p) {
  currentPage = p;
  loadData();
}

function resetAndReload() {
  currentPage = 1;
  loadData();
}

/* ---------------- MODAL TAMBAH / EDIT ---------------- */

const formBuku       = document.getElementById('formBuku');
const modalBukuEl     = document.getElementById('modalBuku');
const modalBuku       = modalBukuEl ? new bootstrap.Modal(modalBukuEl) : null;
const modalBukuTitle  = document.getElementById('modalBukuTitle');
const formAlert       = document.getElementById('formAlert');
const f_preview       = document.getElementById('f_preview');
const f_sampul        = document.getElementById('f_sampul');

const FIELD_IDS = ['kode_buku', 'judul', 'penulis', 'kategori', 'tahun_terbit', 'penerbit'];

function resetForm() {
  formBuku.reset();
  formBuku.classList.remove('was-validated');
  document.getElementById('f_id').value = '';
  f_preview.src = NO_COVER_IMG;
  formAlert.classList.add('d-none');
  formAlert.textContent = '';
  FIELD_IDS.concat(['sampul']).forEach(id => {
    document.getElementById('f_' + id)?.classList.remove('is-invalid');
    const err = document.getElementById('err_' + id);
    if (err) err.textContent = '';
  });
}

function bukaModalTambah() {
  resetForm();
  modalBukuTitle.textContent = 'Tambah Buku';
  modalBuku?.show();
}

async function bukaModalEdit(id) {
  resetForm();
  modalBukuTitle.textContent = 'Edit Buku';

  try {
    const res = await fetch('get_buku.php?id=' + encodeURIComponent(id));
    const result = await res.json();
    if (!result.success) {
      Swal.fire('Gagal', result.message || 'Data tidak ditemukan.', 'error');
      return;
    }

    const buku = result.data;
    document.getElementById('f_id').value = buku.id;
    FIELD_IDS.forEach(key => {
      const el = document.getElementById('f_' + key);
      if (el) el.value = buku[key] ?? '';
    });
    f_preview.src = buku.sampul ? buku.sampul : NO_COVER_IMG;

    modalBuku?.show();
  } catch (err) {
    Swal.fire('Gagal', 'Tidak bisa memuat data buku.', 'error');
  }
}

f_sampul?.addEventListener('change', () => {
  const file = f_sampul.files[0];
  if (file) {
    f_preview.src = URL.createObjectURL(file);
  }
});

document.getElementById('btnTambah')?.addEventListener('click', bukaModalTambah);

formBuku?.addEventListener('submit', async (e) => {
  e.preventDefault();
  formAlert.classList.add('d-none');
  formBuku.classList.remove('was-validated');

  // Validasi ringan di sisi client sebelum kirim
  if (!formBuku.checkValidity()) {
    formBuku.classList.add('was-validated');
    return;
  }

  const file = f_sampul.files[0];
  if (file && file.size > 2 * 1024 * 1024) {
    document.getElementById('f_sampul').classList.add('is-invalid');
    document.getElementById('err_sampul').textContent = 'Ukuran foto maksimal 2MB.';
    return;
  }

  const submitBtn = document.getElementById('btnSimpanBuku');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Menyimpan...';

  try {
    const formData = new FormData(formBuku);
    const res = await fetch('simpan_buku.php', { method: 'POST', body: formData });
    const result = await res.json();

    if (result.success) {
      modalBuku?.hide();
      Swal.fire('Berhasil', result.message, 'success');
      resetAndReload();
    } else {
      if (result.errors) {
        Object.entries(result.errors).forEach(([field, msg]) => {
          const input = document.getElementById('f_' + field);
          const err   = document.getElementById('err_' + field);
          if (input) input.classList.add('is-invalid');
          if (err) err.textContent = msg;
        });
      }
      formAlert.textContent = result.message || 'Gagal menyimpan data.';
      formAlert.classList.remove('d-none');
    }
  } catch (err) {
    formAlert.textContent = 'Terjadi kesalahan saat menghubungi server.';
    formAlert.classList.remove('d-none');
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Simpan';
  }
});

/* ---------------- HAPUS ---------------- */

async function hapusBuku(id) {
  const confirmDelete = () => {
    if (window.Swal) {
      return Swal.fire({
        title: 'Apakah Anda yakin ingin menghapus data ini?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, hapus',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#e5484d'
      }).then(r => r.isConfirmed);
    }
    return Promise.resolve(confirm('Apakah Anda yakin ingin menghapus data ini?'));
  };

  const ok = await confirmDelete();
  if (!ok) return;

  try {
    const res = await fetch('hapus.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'id=' + encodeURIComponent(id)
    });
    const result = await res.json();

    if (result.success) {
      if (window.Swal) Swal.fire('Berhasil', result.message, 'success');
      loadData();
    } else {
      if (window.Swal) Swal.fire('Gagal', result.message, 'error');
      else alert(result.message);
    }
  } catch (err) {
    alert('Terjadi kesalahan saat menghapus data.');
  }
}

/* ---------------- EVENTS ---------------- */

searchInput?.addEventListener('input', () => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(resetAndReload, 350);
});
kategoriFilter?.addEventListener('change', resetAndReload);
sortFilter?.addEventListener('change', resetAndReload);
perPageFilter?.addEventListener('change', resetAndReload);

document.addEventListener('DOMContentLoaded', () => {
  // Dukungan tautan lama: ?aksi=tambah atau ?edit_id=NN membuka modal otomatis
  const params = new URLSearchParams(window.location.search);
  if (params.get('aksi') === 'tambah') {
    bukaModalTambah();
  } else if (params.get('edit_id')) {
    bukaModalEdit(parseInt(params.get('edit_id'), 10));
  }

  loadData();
});
