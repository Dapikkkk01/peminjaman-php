<?php
/**
 * auth.php
 * Include file ini di baris PALING ATAS setiap halaman admin
 * (dashboard.php, data_buku.php, tambah.php, edit.php, export_excel.php,
 * export_pdf.php, data_json.php) untuk memastikan halaman
 * tidak bisa dibuka tanpa login.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function require_login(): void
{
    if (empty($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit;
    }
}
