<?php

require 'auth.php';
require_login();
require 'koneksi.php';


/*
|--------------------------------------------------------------------------
| FILTER
|--------------------------------------------------------------------------
*/

$q = trim($_GET['q'] ?? '');
$kategori = trim($_GET['kategori'] ?? '');
$tahun = trim($_GET['tahun'] ?? '');


/*
|--------------------------------------------------------------------------
| DAFTAR KATEGORI
|--------------------------------------------------------------------------
*/

$kategoriList = $pdo->query(
    "SELECT DISTINCT kategori
     FROM books
     ORDER BY kategori ASC"
)->fetchAll(PDO::FETCH_COLUMN);


/*
|--------------------------------------------------------------------------
| DAFTAR TAHUN
|--------------------------------------------------------------------------
*/

$tahunList = $pdo->query(
    "SELECT DISTINCT tahun_terbit
     FROM books
     ORDER BY tahun_terbit DESC"
)->fetchAll(PDO::FETCH_COLUMN);


/*
|--------------------------------------------------------------------------
| QUERY DATA LAPORAN
|--------------------------------------------------------------------------
*/

$where = [];
$params = [];


if ($q !== '') {

    $where[] = "
        (
            kode_buku LIKE :q_kode
            OR judul LIKE :q_judul
            OR penulis LIKE :q_penulis
            OR kategori LIKE :q_kategori
            OR penerbit LIKE :q_penerbit
        )
    ";

    $search = '%' . $q . '%';
    $params[':q_kode'] = $search;
    $params[':q_judul'] = $search;
    $params[':q_penulis'] = $search;
    $params[':q_kategori'] = $search;
    $params[':q_penerbit'] = $search;
}


if ($kategori !== '') {

    $where[] = "kategori = :kategori";

    $params[':kategori'] = $kategori;
}


if ($tahun !== '') {

    $where[] = "tahun_terbit = :tahun";

    $params[':tahun'] = $tahun;
}


$sql = "
    SELECT
        id,
        kode_buku,
        judul,
        penulis,
        kategori,
        tahun_terbit,
        penerbit,
        created_at
    FROM books
";


if (!empty($where)) {

    $sql .= " WHERE " . implode(" AND ", $where);

}


$sql .= "
    ORDER BY tahun_terbit DESC, id DESC
";


$stmt = $pdo->prepare($sql);

$stmt->execute($params);

$books = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| STATISTIK LAPORAN
|--------------------------------------------------------------------------
*/

$totalBuku = count($books);

$totalKategori = count(
    array_unique(
        array_column($books, 'kategori')
    )
);

$totalPenulis = count(
    array_unique(
        array_column($books, 'penulis')
    )
);

$tahunTerbaru = null;

if (!empty($books)) {

    $tahunTerbaru = max(
        array_column($books, 'tahun_terbit')
    );

}


/*
|--------------------------------------------------------------------------
| DISTRIBUSI KATEGORI
|--------------------------------------------------------------------------
*/

$kategoriData = [];

foreach ($books as $book) {

    $namaKategori = $book['kategori'];

    if (!isset($kategoriData[$namaKategori])) {

        $kategoriData[$namaKategori] = 0;

    }

    $kategoriData[$namaKategori]++;

}


arsort($kategoriData);


?>
<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1"
>

<title>Laporan - Perpustakaan</title>


<?php include 'partials/theme-init.php'; ?>


<link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
>


<link
    rel="stylesheet"
    href="assets/css/style.css"
>
<link rel="stylesheet" href="assets/css/laporan.css">


</head>


<body class="report-page">


<?php include 'partials/sidebar.php'; ?>


<main class="content report-content">


    <!-- =====================================================
         HEADER
    ====================================================== -->

    <div class="report-hero">

        <div>

            <div class="report-kicker">PUSAT INFORMASI</div>
            <h1>Laporan Perpustakaan</h1>

            <span>
                Ringkasan dan laporan koleksi buku
            </span>

        </div>


        <div class="d-flex gap-2">

            <a
                href="export_excel.php<?= !empty($_GET) ? '?' . http_build_query($_GET) : '' ?>"
                class="btn btn-secondary"
            >
                Export Excel
            </a>


            <a
                href="export_pdf.php<?= !empty($_GET) ? '?' . http_build_query($_GET) : '' ?>"
                target="_blank"
                class="btn btn-primary"
            >
                Cetak / PDF
            </a>

        </div>

    </div>


    <!-- =====================================================
         STATISTIK
    ====================================================== -->

    <section class="report-stats">


        <div class="report-stat">

            <span class="stat-label">
                TOTAL BUKU
            </span>

            <span class="stat-value">

                <?= number_format($totalBuku) ?>

            </span>

            <span
                style="
                    color:var(--muted);
                    font-size:.78rem;
                "
            >
                Data sesuai filter
            </span>

        </div>


        <div class="report-stat">

            <span class="stat-label">
                KATEGORI
            </span>

            <span class="stat-value">

                <?= number_format($totalKategori) ?>

            </span>

            <span
                style="
                    color:var(--muted);
                    font-size:.78rem;
                "
            >
                Kategori buku
            </span>

        </div>


        <div class="report-stat">

            <span class="stat-label">
                PENULIS
            </span>

            <span class="stat-value">

                <?= number_format($totalPenulis) ?>

            </span>

            <span
                style="
                    color:var(--muted);
                    font-size:.78rem;
                "
            >
                Penulis berbeda
            </span>

        </div>


        <div class="report-stat">

            <span class="stat-label">
                TAHUN TERBARU
            </span>

            <span class="stat-value">

                <?= $tahunTerbaru ?: '-' ?>

            </span>

            <span
                style="
                    color:var(--muted);
                    font-size:.78rem;
                "
            >
                Tahun terbit
            </span>

        </div>

    </section>


    <!-- =====================================================
         FILTER
    ====================================================== -->

    <section class="report-panel">


        <h2>
            Filter Laporan
        </h2>


        <form
            method="GET"
            class="toolbar"
        >


            <div class="search-wrap">

                <input
                    type="text"
                    name="q"
                    id="searchInput"
                    value="<?= htmlspecialchars($q) ?>"
                    placeholder="Cari judul, penulis, kode..."
                    style="min-width:260px;"
                >

            </div>


            <select
                name="kategori"
                class="form-select"
                style="max-width:210px;"
            >

                <option value="">
                    Semua Kategori
                </option>


                <?php foreach ($kategoriList as $item): ?>

                    <option
                        value="<?= htmlspecialchars($item) ?>"
                        <?= $kategori === $item ? 'selected' : '' ?>
                    >

                        <?= htmlspecialchars($item) ?>

                    </option>

                <?php endforeach; ?>

            </select>


            <select
                name="tahun"
                class="form-select"
                style="max-width:180px;"
            >

                <option value="">
                    Semua Tahun
                </option>


                <?php foreach ($tahunList as $item): ?>

                    <option
                        value="<?= htmlspecialchars($item) ?>"
                        <?= $tahun == $item ? 'selected' : '' ?>
                    >

                        <?= htmlspecialchars($item) ?>

                    </option>

                <?php endforeach; ?>

            </select>


            <button
                type="submit"
                class="btn btn-primary"
            >
                Terapkan
            </button>


            <a
                href="laporan.php"
                class="btn btn-secondary"
            >
                Reset
            </a>


        </form>


        <?php if ($q !== '' || $kategori !== '' || $tahun !== ''): ?>

            <div
                style="
                    color:var(--muted);
                    font-size:.8rem;
                    margin-top:.5rem;
                "
            >

                Filter aktif:

                <?php if ($q !== ''): ?>

                    <span class="badge">
                        Pencarian:
                        <?= htmlspecialchars($q) ?>
                    </span>

                <?php endif; ?>


                <?php if ($kategori !== ''): ?>

                    <span class="badge">
                        Kategori:
                        <?= htmlspecialchars($kategori) ?>
                    </span>

                <?php endif; ?>


                <?php if ($tahun !== ''): ?>

                    <span class="badge">
                        Tahun:
                        <?= htmlspecialchars($tahun) ?>
                    </span>

                <?php endif; ?>

            </div>

        <?php endif; ?>


    </section>


    <!-- =====================================================
         DISTRIBUSI KATEGORI
    ====================================================== -->

    <section class="report-panel">


        <h2>
            Ringkasan Kategori
        </h2>


        <?php if (!empty($kategoriData)): ?>

            <div
                style="
                    display:grid;
                    grid-template-columns:
                        repeat(auto-fit,minmax(180px,1fr));
                    gap:.75rem;
                "
            >

                <?php foreach ($kategoriData as $nama => $jumlah): ?>

                    <div
                        style="
                            padding:1rem;
                            border:1px solid var(--border);
                            border-radius:var(--radius-sm);
                            background:var(--surface-alt);
                        "
                    >

                        <div
                            style="
                                color:var(--muted);
                                font-size:.75rem;
                                margin-bottom:.3rem;
                            "
                        >

                            <?= htmlspecialchars($nama) ?>

                        </div>


                        <div
                            style="
                                font-family:var(--font-head);
                                font-size:1.5rem;
                                font-weight:700;
                                color:var(--accent-strong);
                            "
                        >

                            <?= number_format($jumlah) ?>

                        </div>


                        <div
                            style="
                                color:var(--muted);
                                font-size:.72rem;
                            "
                        >

                            buku

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <div class="empty-state">

                Tidak ada data kategori.

            </div>

        <?php endif; ?>


    </section>


    <!-- =====================================================
         TABEL LAPORAN
    ====================================================== -->

    <section class="report-panel">


        <div
            style="
                display:flex;
                justify-content:space-between;
                align-items:center;
                margin-bottom:1rem;
                gap:1rem;
            "
        >

            <div>

                <h2>
                    Data Buku
                </h2>

                <div
                    style="
                        color:var(--muted);
                        font-size:.8rem;
                    "
                >

                    Menampilkan
                    <?= number_format($totalBuku) ?>
                    data buku

                </div>

            </div>


            <span class="badge">

                <?= date('d/m/Y') ?>

            </span>

        </div>


        <div class="table-wrap">

            <table>

                <thead>

                    <tr>

                        <th>
                            No
                        </th>

                        <th>
                            Kode
                        </th>

                        <th>
                            Judul
                        </th>

                        <th>
                            Penulis
                        </th>

                        <th>
                            Kategori
                        </th>

                        <th>
                            Tahun
                        </th>

                        <th>
                            Penerbit
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php if (!empty($books)): ?>


                    <?php foreach ($books as $index => $book): ?>

                        <tr>

                            <td>
                                <?= $index + 1 ?>
                            </td>


                            <td>

                                <strong>
                                    <?= htmlspecialchars(
                                        $book['kode_buku']
                                    ) ?>
                                </strong>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $book['judul']
                                ) ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $book['penulis']
                                ) ?>

                            </td>


                            <td>

                                <span class="badge">

                                    <?= htmlspecialchars(
                                        $book['kategori']
                                    ) ?>

                                </span>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $book['tahun_terbit']
                                ) ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $book['penerbit']
                                ) ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>


                <?php else: ?>


                    <tr>

                        <td
                            colspan="7"
                            class="empty-state"
                        >

                            Tidak ada data yang
                            sesuai dengan filter.

                        </td>

                    </tr>


                <?php endif; ?>


                </tbody>

            </table>

        </div>


    </section>


</main>


<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>


</body>

</html>
