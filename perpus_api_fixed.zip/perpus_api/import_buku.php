
<?php

require_once 'auth.php';
require_login();

require_once 'koneksi.php';

/*
|--------------------------------------------------------------------------
| PhpSpreadsheet
|--------------------------------------------------------------------------
| Library ini digunakan untuk membaca file Excel.
|
| Jika muncul pesan "PhpSpreadsheet belum terpasang",
| jalankan:
|
| composer require phpoffice/phpspreadsheet
|
*/

$autoload = __DIR__ . '/vendor/autoload.php';

$message = '';
$messageType = '';

/*
|--------------------------------------------------------------------------
| Cek PhpSpreadsheet
|--------------------------------------------------------------------------
*/

if (!file_exists($autoload)) {

    $message =
        'Library PhpSpreadsheet belum terpasang.<br><br>' .
        'Buka Terminal/CMD di folder project lalu jalankan:<br>' .
        '<code>composer require phpoffice/phpspreadsheet</code>';

    $messageType = 'error';

} else {

    require_once $autoload;

    /*
    |--------------------------------------------------------------------------
    | Proses Import Excel
    |--------------------------------------------------------------------------
    */

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        /*
        |--------------------------------------------------------------------------
        | Cek file upload
        |--------------------------------------------------------------------------
        */

        if (!isset($_FILES['file_excel'])) {

            $message = 'File Excel belum dipilih.';
            $messageType = 'error';

        } elseif ($_FILES['file_excel']['error'] !== UPLOAD_ERR_OK) {

            $message = 'File Excel gagal diupload.';
            $messageType = 'error';

        } else {

            $file = $_FILES['file_excel'];

            /*
            |--------------------------------------------------------------------------
            | Cek ekstensi
            |--------------------------------------------------------------------------
            */

            $extension = strtolower(
                pathinfo($file['name'], PATHINFO_EXTENSION)
            );

            if (!in_array($extension, ['xlsx', 'xls'], true)) {

                $message = 'Format file harus .xlsx atau .xls.';
                $messageType = 'error';

            } else {

                try {

                    /*
                    |--------------------------------------------------------------------------
                    | Load PhpSpreadsheet
                    |--------------------------------------------------------------------------
                    */

                    $spreadsheet =
                        \PhpOffice\PhpSpreadsheet\IOFactory::load(
                            $file['tmp_name']
                        );

                    $sheet = $spreadsheet->getActiveSheet();

                    /*
                    |--------------------------------------------------------------------------
                    | Ambil semua data Excel
                    |--------------------------------------------------------------------------
                    */

                    $rows = $sheet->toArray(
                        null,
                        true,
                        true,
                        true
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Minimal harus ada header + 1 data
                    |--------------------------------------------------------------------------
                    */

                    if (count($rows) < 2) {

                        throw new Exception(
                            'File Excel tidak memiliki data buku.'
                        );
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | Kolom yang wajib ada
                    |--------------------------------------------------------------------------
                    */

                    $requiredHeaders = [
                        'kode_buku',
                        'judul',
                        'penulis',
                        'kategori',
                        'tahun_terbit',
                        'penerbit'
                    ];

                    /*
                    |--------------------------------------------------------------------------
                    | Ambil header Excel
                    |--------------------------------------------------------------------------
                    */

                    $headers = array_map(
                        function ($value) {

                            return strtolower(
                                trim((string) $value)
                            );

                        },
                        $rows[1]
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Buat mapping kolom
                    |--------------------------------------------------------------------------
                    */

                    $headerMap = [];

                    foreach ($headers as $column => $header) {

                        if ($header !== '') {

                            $headerMap[$header] = $column;
                        }
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | Pastikan semua kolom tersedia
                    |--------------------------------------------------------------------------
                    */

                    foreach ($requiredHeaders as $required) {

                        if (!isset($headerMap[$required])) {

                            throw new Exception(
                                "Kolom '{$required}' tidak ditemukan di file Excel."
                            );
                        }
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | Statistik import
                    |--------------------------------------------------------------------------
                    */

                    $berhasil = 0;
                    $duplikat = 0;
                    $gagal = 0;

                    $errorRows = [];

                    /*
                    |--------------------------------------------------------------------------
                    | Query cek kode buku
                    |--------------------------------------------------------------------------
                    |
                    | Koneksi project menggunakan PDO.
                    |
                    */

                    $checkStmt = $pdo->prepare(
                        "SELECT id
                         FROM books
                         WHERE kode_buku = :kode
                         LIMIT 1"
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Query insert buku
                    |--------------------------------------------------------------------------
                    */

                    $insertStmt = $pdo->prepare(
                        "INSERT INTO books
                        (
                            kode_buku,
                            judul,
                            penulis,
                            kategori,
                            tahun_terbit,
                            penerbit
                        )
                        VALUES
                        (
                            :kode,
                            :judul,
                            :penulis,
                            :kategori,
                            :tahun,
                            :penerbit
                        )"
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Mulai transaksi
                    |--------------------------------------------------------------------------
                    */

                    $pdo->beginTransaction();

                    /*
                    |--------------------------------------------------------------------------
                    | Proses setiap baris Excel
                    |--------------------------------------------------------------------------
                    */

                    foreach ($rows as $rowNumber => $row) {

                        /*
                        |--------------------------------------------------------------------------
                        | Lewati baris header
                        |--------------------------------------------------------------------------
                        */

                        if ($rowNumber === 1) {
                            continue;
                        }

                        /*
                        |--------------------------------------------------------------------------
                        | Ambil data berdasarkan nama kolom
                        |--------------------------------------------------------------------------
                        */

                        $kode = trim(
                            (string) (
                                $row[$headerMap['kode_buku']] ?? ''
                            )
                        );

                        $judul = trim(
                            (string) (
                                $row[$headerMap['judul']] ?? ''
                            )
                        );

                        $penulis = trim(
                            (string) (
                                $row[$headerMap['penulis']] ?? ''
                            )
                        );

                        $kategori = trim(
                            (string) (
                                $row[$headerMap['kategori']] ?? ''
                            )
                        );

                        $tahun = trim(
                            (string) (
                                $row[$headerMap['tahun_terbit']] ?? ''
                            )
                        );

                        $penerbit = trim(
                            (string) (
                                $row[$headerMap['penerbit']] ?? ''
                            )
                        );

                        /*
                        |--------------------------------------------------------------------------
                        | Lewati baris kosong
                        |--------------------------------------------------------------------------
                        */

                        if (
                            $kode === '' &&
                            $judul === '' &&
                            $penulis === '' &&
                            $kategori === '' &&
                            $tahun === '' &&
                            $penerbit === ''
                        ) {

                            continue;
                        }

                        /*
                        |--------------------------------------------------------------------------
                        | Validasi data kosong
                        |--------------------------------------------------------------------------
                        */

                        if (
                            $kode === '' ||
                            $judul === '' ||
                            $penulis === '' ||
                            $kategori === '' ||
                            $tahun === '' ||
                            $penerbit === ''
                        ) {

                            $gagal++;

                            $errorRows[] =
                                "Baris {$rowNumber}: terdapat data yang kosong.";

                            continue;
                        }

                        /*
                        |--------------------------------------------------------------------------
                        | Validasi tahun
                        |--------------------------------------------------------------------------
                        */

                        if (
                            !is_numeric($tahun) ||
                            (int) $tahun < 1000 ||
                            (int) $tahun > 9999
                        ) {

                            $gagal++;

                            $errorRows[] =
                                "Baris {$rowNumber}: tahun terbit '{$tahun}' tidak valid.";

                            continue;
                        }

                        /*
                        |--------------------------------------------------------------------------
                        | Cek kode buku apakah sudah ada
                        |--------------------------------------------------------------------------
                        */

                        $checkStmt->execute([
                            ':kode' => $kode
                        ]);

                        $existingBook =
                            $checkStmt->fetch(PDO::FETCH_ASSOC);

                        if ($existingBook) {

                            $duplikat++;

                            $errorRows[] =
                                "Baris {$rowNumber}: kode buku '{$kode}' sudah ada.";

                            continue;
                        }

                        /*
                        |--------------------------------------------------------------------------
                        | Simpan buku
                        |--------------------------------------------------------------------------
                        */

                        $insertStmt->execute([
                            ':kode'      => $kode,
                            ':judul'     => $judul,
                            ':penulis'   => $penulis,
                            ':kategori'  => $kategori,
                            ':tahun'     => (int) $tahun,
                            ':penerbit'  => $penerbit
                        ]);

                        $berhasil++;
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | Commit transaksi
                    |--------------------------------------------------------------------------
                    */

                    $pdo->commit();

                    /*
                    |--------------------------------------------------------------------------
                    | Pesan hasil
                    |--------------------------------------------------------------------------
                    */

                    $message =
                        "Import selesai.<br>" .
                        "Berhasil: <strong>{$berhasil}</strong><br>" .
                        "Duplikat: <strong>{$duplikat}</strong><br>" .
                        "Gagal: <strong>{$gagal}</strong>";

                    $messageType =
                        $berhasil > 0
                            ? 'success'
                            : 'error';

                    /*
                    |--------------------------------------------------------------------------
                    | Detail error
                    |--------------------------------------------------------------------------
                    */

                    if (!empty($errorRows)) {

                        $message .=
                            '<br><br>' .
                            '<strong>Detail:</strong><br>';

                        foreach ($errorRows as $error) {

                            $message .=
                                htmlspecialchars(
                                    $error,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) .
                                '<br>';
                        }
                    }

                } catch (Throwable $e) {

                    /*
                    |--------------------------------------------------------------------------
                    | Rollback jika terjadi error
                    |--------------------------------------------------------------------------
                    */

                    if ($pdo->inTransaction()) {

                        $pdo->rollBack();
                    }

                    $message =
                        'Import gagal: ' .
                        htmlspecialchars(
                            $e->getMessage(),
                            ENT_QUOTES,
                            'UTF-8'
                        );

                    $messageType = 'error';
                }
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Import Buku - Perpustakaan</title>

    <?php include 'partials/theme-init.php'; ?>

    <link
        rel="stylesheet"
        href="assets/css/style.css"
    >

</head>

<body>

<?php include 'partials/sidebar.php'; ?>


<main class="content">

    <!-- TOPBAR -->

    <div class="topbar">

        <div>

            <h1>Import Data Buku</h1>

            <span>
                Tambahkan banyak data buku melalui file Excel
            </span>

        </div>

        <a
            href="data_buku.php"
            class="btn btn-secondary"
        >
            ← Kembali
        </a>

    </div>


    <!-- PESAN -->

    <?php if ($message): ?>

        <div
            class="alert
            <?= $messageType === 'success'
                ? 'alert-success'
                : 'alert-error'
            ?>"
        >

            <?= $message ?>

        </div>

    <?php endif; ?>


    <!-- FORM IMPORT -->

    <section class="panel">

        <h2>Import Excel</h2>

        <p
            style="
                color: var(--muted);
                margin-top: -0.4rem;
            "
        >
            Gunakan template Excel agar format data sesuai
            dengan struktur tabel buku.
        </p>


        <!-- DOWNLOAD TEMPLATE -->

        <div class="toolbar">

            <a
                href="template_import_buku.xlsx"
                class="btn btn-secondary"
                download
            >
                📥 Download Template Excel
            </a>

        </div>


        <!-- FORM -->

        <form
            method="POST"
            enctype="multipart/form-data"
        >

            <div class="form-grid">

                <div class="form-group full">

                    <label for="file_excel">
                        File Excel
                    </label>

                    <input
                        type="file"
                        name="file_excel"
                        id="file_excel"
                        class="form-control"
                        accept=".xlsx,.xls"
                        required
                    >

                    <small
                        style="color: var(--muted);"
                    >
                        Format yang diperbolehkan:
                        .xlsx dan .xls
                    </small>

                </div>

            </div>


            <div class="form-actions">

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    Import Buku
                </button>

                <a
                    href="data_buku.php"
                    class="btn btn-secondary"
                >
                    Batal
                </a>

            </div>

        </form>

    </section>


    <!-- FORMAT EXCEL -->

    <section class="panel">

        <h2>Format Excel</h2>

        <p
            style="
                color: var(--muted);
            "
        >
            Baris pertama Excel harus berisi nama kolom berikut.
        </p>

        <div class="table-wrap">

            <table>

                <thead>

                    <tr>

                        <th>Kolom</th>

                        <th>Keterangan</th>

                        <th>Contoh</th>

                    </tr>

                </thead>

                <tbody>

                    <tr>

                        <td>
                            <strong>kode_buku</strong>
                        </td>

                        <td>
                            Kode unik buku
                        </td>

                        <td>
                            BK001
                        </td>

                    </tr>


                    <tr>

                        <td>
                            <strong>judul</strong>
                        </td>

                        <td>
                            Judul buku
                        </td>

                        <td>
                            Laskar Pelangi
                        </td>

                    </tr>


                    <tr>

                        <td>
                            <strong>penulis</strong>
                        </td>

                        <td>
                            Nama penulis
                        </td>

                        <td>
                            Andrea Hirata
                        </td>

                    </tr>


                    <tr>

                        <td>
                            <strong>kategori</strong>
                        </td>

                        <td>
                            Kategori buku
                        </td>

                        <td>
                            Novel
                        </td>

                    </tr>


                    <tr>

                        <td>
                            <strong>tahun_terbit</strong>
                        </td>

                        <td>
                            Tahun terbit
                        </td>

                        <td>
                            2005
                        </td>

                    </tr>


                    <tr>

                        <td>
                            <strong>penerbit</strong>
                        </td>

                        <td>
                            Nama penerbit
                        </td>

                        <td>
                            Bentang Pustaka
                        </td>

                    </tr>

                </tbody>

            </table>

        </div>

    </section>

</main>

</body>

</html>