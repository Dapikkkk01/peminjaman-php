```php
<?php
require 'auth.php';
require_login();
require 'koneksi.php';

/*
|--------------------------------------------------------------------------
| STATISTIK
|--------------------------------------------------------------------------
| Semua data tetap diambil langsung dari database.
*/

$total_buku = $pdo->query(
    "SELECT COUNT(*) FROM books"
)->fetchColumn();

$jumlah_kategori = $pdo->query(
    "SELECT COUNT(DISTINCT kategori) FROM books"
)->fetchColumn();

$jumlah_penulis = $pdo->query(
    "SELECT COUNT(DISTINCT penulis) FROM books"
)->fetchColumn();

$tahun_terbaru = $pdo->query(
    "SELECT MAX(tahun_terbit) FROM books"
)->fetchColumn();


/*
|--------------------------------------------------------------------------
| DATA GRAFIK KATEGORI
|--------------------------------------------------------------------------
*/

$kategoriChart = $pdo->query(
    "SELECT kategori, COUNT(*) AS jumlah
     FROM books
     GROUP BY kategori
     ORDER BY jumlah DESC"
)->fetchAll(PDO::FETCH_ASSOC);

$labelsKategori = array_column(
    $kategoriChart,
    'kategori'
);

$dataKategori = array_column(
    $kategoriChart,
    'jumlah'
);


/*
|--------------------------------------------------------------------------
| BUKU TERBARU
|--------------------------------------------------------------------------
*/

$bukuTerbaru = $pdo->query(
    "SELECT judul, penulis, kategori, tahun_terbit
     FROM books
     ORDER BY id DESC
     LIMIT 5"
)->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1">

<title>Dashboard - Perpustakaan</title>

<?php include 'partials/theme-init.php'; ?>

<link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
>

<link
    rel="stylesheet"
    href="assets/css/style.css"
>

<script
    src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js">
</script>

</head>


<body>

<?php include 'partials/sidebar.php'; ?>


<main class="content">

    <!-- =====================================================
         HEADER
    ====================================================== -->

    <div class="topbar">

        <div>

            <h1>
                Dashboard
            </h1>

            <div
                style="
                    color: var(--muted);
                    font-size: .88rem;
                    margin-top: .25rem;
                "
            >
                Ringkasan dan aktivitas perpustakaan
            </div>

        </div>


        <span>

            Halo,
            <strong>
                <?= htmlspecialchars($_SESSION['admin_username']) ?>
            </strong>

        </span>

    </div>


    <!-- =====================================================
         STATISTIK
    ====================================================== -->

    <section class="cards-grid">


        <!-- TOTAL BUKU -->

        <div class="stat-card">

            <span class="stat-label">
                TOTAL BUKU
            </span>

            <span class="stat-value">

                <?= number_format((int)$total_buku) ?>

            </span>

            <span
                style="
                    color: var(--muted);
                    font-size: .78rem;
                "
            >
                Koleksi buku tersedia
            </span>

        </div>


        <!-- KATEGORI -->

        <div class="stat-card">

            <span class="stat-label">
                KATEGORI
            </span>

            <span class="stat-value">

                <?= number_format((int)$jumlah_kategori) ?>

            </span>

            <span
                style="
                    color: var(--muted);
                    font-size: .78rem;
                "
            >
                Kategori koleksi
            </span>

        </div>


        <!-- PENULIS -->

        <div class="stat-card">

            <span class="stat-label">
                DATA PENULIS
            </span>

            <span class="stat-value">

                <?= number_format((int)$jumlah_penulis) ?>

            </span>

            <span
                style="
                    color: var(--muted);
                    font-size: .78rem;
                "
            >
                Penulis terdaftar
            </span>

        </div>


        <!-- TAHUN TERBARU -->

        <div class="stat-card">

            <span class="stat-label">
                TERBITAN TERBARU
            </span>

            <span class="stat-value">

                <?= $tahun_terbaru
                    ? (int)$tahun_terbaru
                    : '-'
                ?>

            </span>

            <span
                style="
                    color: var(--muted);
                    font-size: .78rem;
                "
            >
                Tahun terbit terbaru
            </span>

        </div>

    </section>


    <!-- =====================================================
         GRAFIK + AKSES CEPAT
    ====================================================== -->

    <section
        class="row g-3"
        style="margin-bottom: 1.5rem;"
    >


        <!-- GRAFIK -->

        <div class="col-lg-8">

            <div class="panel h-100">

                <div
                    style="
                        display:flex;
                        justify-content:space-between;
                        align-items:flex-start;
                        gap:1rem;
                        margin-bottom:1rem;
                    "
                >

                    <div>

                        <h2>
                            Distribusi Kategori Buku
                        </h2>

                        <div
                            style="
                                color:var(--muted);
                                font-size:.8rem;
                            "
                        >
                            Jumlah koleksi berdasarkan kategori
                        </div>

                    </div>

                </div>


                <div style="height:320px;">

                    <canvas id="chartKategori"></canvas>

                </div>

            </div>

        </div>


        <!-- AKSES CEPAT -->

        <div class="col-lg-4">

            <div class="panel h-100">

                <h2>
                    Akses Cepat
                </h2>


                <div
                    style="
                        display:flex;
                        flex-direction:column;
                        gap:.65rem;
                        margin-top:1.2rem;
                    "
                >

                    <a
                        href="data_buku.php"
                        class="btn btn-primary"
                    >
                        Kelola Buku
                    </a>


                    <a
                        href="data_buku.php?aksi=tambah"
                        class="btn btn-secondary"
                    >
                        + Tambah Buku
                    </a>


                    <a
                        href="laporan.php"
                        class="btn btn-secondary"
                    >
                        Lihat Laporan
                    </a>

                </div>

            </div>

        </div>

    </section>


    <!-- =====================================================
         BUKU TERBARU
    ====================================================== -->

    <section class="panel">

        <div
            style="
                display:flex;
                justify-content:space-between;
                align-items:center;
                gap:1rem;
                margin-bottom:1rem;
            "
        >

            <div>

                <h2>
                    Buku Terbaru
                </h2>

                <div
                    style="
                        color:var(--muted);
                        font-size:.8rem;
                    "
                >
                    Koleksi buku yang baru ditambahkan
                </div>

            </div>


            <a
                href="data_buku.php"
                class="btn btn-secondary btn-sm"
            >
                Lihat Semua
            </a>

        </div>


        <?php if (count($bukuTerbaru) > 0): ?>

            <div class="table-wrap">

                <table>

                    <thead>

                        <tr>

                            <th>
                                Judul
                            </th>

                            <th>
                                Penulis
                            </th>

                            <th>
                                Kategori
                            </th>

                            <th>
                                Tahun
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php foreach ($bukuTerbaru as $buku): ?>

                        <tr>

                            <td>

                                <strong>
                                    <?= htmlspecialchars(
                                        $buku['judul']
                                    ) ?>
                                </strong>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $buku['penulis']
                                ) ?>

                            </td>


                            <td>

                                <span class="badge">

                                    <?= htmlspecialchars(
                                        $buku['kategori']
                                    ) ?>

                                </span>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $buku['tahun_terbit']
                                ) ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php else: ?>

            <div class="empty-state">

                Belum ada data buku.

            </div>

        <?php endif; ?>

    </section>

</main>


<!-- =====================================================
     BOOTSTRAP
====================================================== -->

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>


<script>

/*
|--------------------------------------------------------------------------
| CHART
|--------------------------------------------------------------------------
| Warna mengikuti tema yang sudah dibuat di style.css.
*/

const root = document.documentElement;

const styles = getComputedStyle(root);

const accent = styles
    .getPropertyValue('--accent')
    .trim();

const textColor = styles
    .getPropertyValue('--text')
    .trim();

const mutedColor = styles
    .getPropertyValue('--muted')
    .trim();

const borderColor = styles
    .getPropertyValue('--border')
    .trim();


const ctx =
    document.getElementById('chartKategori');


new Chart(ctx, {

    type: 'bar',

    data: {

        labels:
            <?= json_encode(
                $labelsKategori,
                JSON_UNESCAPED_UNICODE
            ) ?>,

        datasets: [

            {

                label: 'Jumlah Buku',

                data:
                    <?= json_encode(
                        $dataKategori
                    ) ?>,

                backgroundColor: accent,

                borderRadius: 8,

                borderSkipped: false,

                maxBarThickness: 48

            }

        ]

    },


    options: {

        responsive: true,

        maintainAspectRatio: false,


        plugins: {

            legend: {

                display: false

            },


            tooltip: {

                backgroundColor:
                    styles.getPropertyValue('--card-bg').trim(),

                titleColor: textColor,

                bodyColor: mutedColor,

                borderColor: borderColor,

                borderWidth: 1,

                padding: 12,

                displayColors: false

            }

        },


        scales: {

            y: {

                beginAtZero: true,

                ticks: {

                    stepSize: 1,

                    color: mutedColor

                },

                grid: {

                    color: borderColor

                }

            },


            x: {

                ticks: {

                    color: mutedColor

                },

                grid: {

                    display: false

                }

            }

        }

    }

});

</script>

</body>

</html>
```
