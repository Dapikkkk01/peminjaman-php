<?php
require 'auth.php';
require_login();
require 'koneksi.php';

$kategoriList = $pdo->query("SELECT DISTINCT kategori FROM books ORDER BY kategori")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Data Buku - Perpustakaan</title>
<?php include 'partials/theme-init.php'; ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/style.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.12.0/sweetalert2.all.min.js"></script>
</head>
<body>
<?php include 'partials/sidebar.php'; ?>

<main class="content">
  <div class="topbar">
    <h1>Data Buku</h1>
    <button type="button" class="btn btn-primary" id="btnTambah" data-bs-toggle="modal" data-bs-target="#modalBuku">+ Tambah Buku</button>
  </div>

  <section class="panel">
    <div class="toolbar">
      <div class="search-wrap">
        <input type="text" id="searchInput" class="form-control" placeholder="Cari kode / judul / penulis / kategori..." style="max-width:260px">
      </div>
      <select id="kategoriFilter" class="form-select" style="max-width:200px">
        <option value="">Semua Kategori</option>
        <?php foreach ($kategoriList as $k): ?>
          <option value="<?= htmlspecialchars($k) ?>"><?= htmlspecialchars($k) ?></option>
        <?php endforeach; ?>
      </select>
      <select id="sortFilter" class="form-select" style="max-width:200px">
        <option value="">Urutkan (default)</option>
        <option value="tahun_asc">Tahun Terbit ↑</option>
        <option value="tahun_desc">Tahun Terbit ↓</option>
      </select>
      <select id="perPageFilter" class="form-select" style="max-width:150px">
        <option value="5">5 / halaman</option>
        <option value="10">10 / halaman</option>
        <option value="25">25 / halaman</option>
      </select>

      <div class="ms-auto d-flex gap-2">
        <a id="btnExportExcel" href="export_excel.php" class="btn btn-secondary btn-sm">📥 Export Excel</a>
        <a id="btnExportPdf" href="export_pdf.php" class="btn btn-secondary btn-sm">🖨️ Cetak Laporan</a>
        <a href="import_buku.php" class="btn btn-secondary">📥 Import Excel</a>
      </div>
    </div>
    <p class="text-muted small mb-2">
      Export &amp; cetak laporan di atas otomatis mengikuti kata kunci pencarian dan kategori yang sedang aktif.
    </p>

    <div class="table-wrap">
      <table class="table align-middle">
        <thead>
          <tr>
            <th>No</th>
            <th>Sampul</th>
            <th>Kode Buku</th>
            <th>Judul</th>
            <th>Penulis</th>
            <th>Kategori</th>
            <th>Tahun Terbit</th>
            <th>Penerbit</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody id="tabelBuku">
          <tr><td colspan="9" class="loading-state">Memuat data...</td></tr>
        </tbody>
      </table>
    </div>

    <nav aria-label="Navigasi halaman">
      <ul class="pagination justify-content-center mb-0" id="paginationBuku"></ul>
    </nav>
  </section>
</main>

<!-- MODAL FORM TAMBAH / EDIT BUKU -->
<div class="modal fade" id="modalBuku" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <form id="formBuku" novalidate>
        <div class="modal-header">
          <h5 class="modal-title" id="modalBukuTitle">Tambah Buku</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="modal-body">
          <div id="formAlert" class="alert alert-danger d-none"></div>

          <input type="hidden" name="id" id="f_id" value="">

          <div class="row g-3">
            <div class="col-md-4 text-center">
              <label class="form-label d-block">Foto Sampul</label>
              <img id="f_preview" src="" alt="Preview sampul" class="cover-preview mb-2">
              <input type="file" name="sampul" id="f_sampul" class="form-control form-control-sm" accept=".jpg,.jpeg,.png,.webp">
              <div class="invalid-feedback" id="err_sampul"></div>
              <small class="text-muted">JPG/PNG/WEBP, maks 2MB. Opsional.</small>
            </div>

            <div class="col-md-8">
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label">Kode Buku</label>
                  <input type="text" name="kode_buku" id="f_kode_buku" class="form-control" required>
                  <div class="invalid-feedback" id="err_kode_buku"></div>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Tahun Terbit</label>
                  <input type="number" name="tahun_terbit" id="f_tahun_terbit" class="form-control" min="1900" max="<?= date('Y') + 1 ?>" required>
                  <div class="invalid-feedback" id="err_tahun_terbit"></div>
                </div>
                <div class="col-12">
                  <label class="form-label">Judul</label>
                  <input type="text" name="judul" id="f_judul" class="form-control" required>
                  <div class="invalid-feedback" id="err_judul"></div>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Penulis</label>
                  <input type="text" name="penulis" id="f_penulis" class="form-control" required>
                  <div class="invalid-feedback" id="err_penulis"></div>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Kategori</label>
                  <input type="text" name="kategori" id="f_kategori" class="form-control" list="kategoriOptions" required>
                  <datalist id="kategoriOptions">
                    <?php foreach ($kategoriList as $k): ?>
                      <option value="<?= htmlspecialchars($k) ?>">
                    <?php endforeach; ?>
                  </datalist>
                  <div class="invalid-feedback" id="err_kategori"></div>
                </div>
                <div class="col-12">
                  <label class="form-label">Penerbit</label>
                  <input type="text" name="penerbit" id="f_penerbit" class="form-control" required>
                  <div class="invalid-feedback" id="err_penerbit"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary" id="btnSimpanBuku">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
