<?php
$current = basename($_SERVER['PHP_SELF']);
function navActive($file, $current) { return $file === $current ? 'active' : ''; }
?>
<aside class="sidebar">
  <div class="sidebar-brand">📚 Perpus Admin</div>
  <nav>
    <a href="dashboard.php" class="<?= navActive('dashboard.php', $current) ?>">📊 Dashboard</a>
    <a href="data_buku.php" class="<?= navActive('data_buku.php', $current) ?>">📖 Data Buku</a>
    <a href="data_buku.php?aksi=tambah">➕ Tambah Buku</a>
    <a href="export_excel.php">📥 Export Excel</a>
    <a href="laporan.php" class="<?= navActive('laporan.php', $current) ?>">📑 Laporan</a>
    <a href="export_pdf.php">🖨️ Cetak Laporan</a>
  </nav>
  <div class="sidebar-bottom">
    <button type="button" id="darkModeToggle" class="btn btn-sm btn-outline-light w-100 mb-2">
      🌙 <span id="darkModeLabel">Mode Gelap</span>
    </button>
    <a href="logout.php" class="logout">🚪 Logout</a>
  </div>
</aside>
<button class="sidebar-toggle" onclick="document.querySelector('.sidebar').classList.toggle('open')">☰</button>

<script>
(function () {
  var toggleBtn = document.getElementById('darkModeToggle');
  var label     = document.getElementById('darkModeLabel');

  function syncLabel() {
    var isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
    label.textContent = isDark ? 'Mode Terang' : 'Mode Gelap';
  }

  syncLabel();

  toggleBtn?.addEventListener('click', function () {
    var isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
    if (isDark) {
      document.documentElement.removeAttribute('data-bs-theme');
      localStorage.setItem('perpus_theme', 'light');
    } else {
      document.documentElement.setAttribute('data-bs-theme', 'dark');
      localStorage.setItem('perpus_theme', 'dark');
    }
    syncLabel();
  });
})();
</script>
