<script>
  (function () {
    var saved = localStorage.getItem('perpus_theme');
    if (saved === 'dark') {
      document.documentElement.setAttribute('data-bs-theme', 'dark');
    }
  })();
</script>
