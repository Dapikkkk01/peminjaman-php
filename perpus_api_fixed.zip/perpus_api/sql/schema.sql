-- =========================================================
-- schema.sql — Database perpus_api
-- Jalankan seluruh isi file ini di tab SQL phpMyAdmin
-- =========================================================

CREATE DATABASE IF NOT EXISTS perpus_api CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE perpus_api;

-- ---------------------------------------------------------
-- Tabel admins
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS admins (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50)  NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

-- Akun admin ujian: admin / admin123
-- (password sudah dalam bentuk hash bcrypt, dibuat dengan password_hash())
INSERT INTO admins (username, password) VALUES
('admin', '$2b$12$ZL/lcNFCKpOMX3yTHpBZY.jy1BlXI52NrgmYvyB7w1DWX9hfLx9ES');

-- ---------------------------------------------------------
-- Tabel books
-- Kolom `sampul` menyimpan path relatif ke file foto sampul
-- (mis. assets/img/covers/xxxxx.jpg), NULL jika belum diunggah.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS books (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    kode_buku    VARCHAR(30)  NOT NULL UNIQUE,
    judul        VARCHAR(150) NOT NULL,
    penulis      VARCHAR(100) NOT NULL,
    kategori     VARCHAR(50)  NOT NULL,
    tahun_terbit YEAR         NOT NULL,
    penerbit     VARCHAR(100) NOT NULL,
    sampul       VARCHAR(255) NULL,
    created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO books (kode_buku, judul, penulis, kategori, tahun_terbit, penerbit, sampul) VALUES
('BK-001', 'Laskar Pelangi',                 'Andrea Hirata',      'Fiksi',        2005, 'Bentang Pustaka', NULL),
('BK-002', 'Bumi Manusia',                   'Pramoedya A. Toer',  'Fiksi',        1980, 'Hasta Mitra',     NULL),
('BK-003', 'Filosofi Teras',                 'Henry Manampiring',  'Pengembangan Diri', 2018, 'Kompas',    NULL),
('BK-004', 'Sapiens',                        'Yuval Noah Harari',  'Sains',        2011, 'Pustaka Alvabet', NULL),
('BK-005', 'Atomic Habits',                  'James Clear',        'Pengembangan Diri', 2018, 'Gramedia',  NULL),
('BK-006', 'Clean Code',                     'Robert C. Martin',   'Teknologi',    2008, 'Prentice Hall',   NULL),
('BK-007', 'Cosmos',                         'Carl Sagan',         'Sains',        1980, 'Random House',    NULL),
('BK-008', 'Negeri 5 Menara',                'Ahmad Fuadi',        'Fiksi',        2009, 'Gramedia',        NULL),
('BK-009', 'Sejarah Indonesia Modern',       'M.C. Ricklefs',      'Sejarah',      2001, 'Serambi',         NULL),
('BK-010', 'Design Patterns',                'Erich Gamma dkk',    'Teknologi',    1994, 'Addison-Wesley',  NULL);
