<?php
/**
 * get_buku.php
 * Endpoint AJAX: kembalikan data satu buku (untuk mengisi modal edit).
 */

require 'auth.php';
require_login();
header('Content-Type: application/json; charset=utf-8');
require 'koneksi.php';

$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID tidak valid.']);
    exit;
}

try {
    $stmt = $pdo->prepare(
        "SELECT id, kode_buku, judul, penulis, kategori, tahun_terbit, penerbit, sampul FROM books WHERE id = ?"
    );
    $stmt->execute([$id]);
    $buku = $stmt->fetch();

    if (!$buku) {
        echo json_encode(['success' => false, 'message' => 'Data buku tidak ditemukan.']);
        exit;
    }

    echo json_encode(['success' => true, 'data' => $buku]);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => 'Gagal mengambil data buku.']);
}
