<?php
/**
 * edit.php
 * Fitur "Edit Buku" sekarang menggunakan MODAL FORM di data_buku.php.
 * File ini dipertahankan hanya supaya tautan lama tetap berfungsi,
 * dengan mengarahkan ke modal edit untuk id yang bersangkutan.
 */
require 'auth.php';
require_login();
$id = (int)($_GET['id'] ?? 0);
header('Location: data_buku.php?edit_id=' . $id);
exit;
