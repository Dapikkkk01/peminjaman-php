<?php
require 'auth.php';
require_login();
header('Content-Type: application/json; charset=utf-8');
require 'koneksi.php';

$id = (int)($_POST['id'] ?? 0);

if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID tidak valid.']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT sampul FROM books WHERE id = ?");
    $stmt->execute([$id]);
    $buku = $stmt->fetch();
    if (!$buku) {
        echo json_encode(['success' => false, 'message' => 'Data tidak ditemukan.']);
        exit;
    }

    $del = $pdo->prepare("DELETE FROM books WHERE id = ?");
    $del->execute([$id]);

    // Bersihkan file foto sampul dari server (jika ada)
    if (!empty($buku['sampul']) && file_exists(__DIR__ . '/' . $buku['sampul'])) {
        @unlink(__DIR__ . '/' . $buku['sampul']);
    }

    echo json_encode(['success' => true, 'message' => 'Data buku berhasil dihapus.']);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => 'Gagal menghapus data.']);
}
