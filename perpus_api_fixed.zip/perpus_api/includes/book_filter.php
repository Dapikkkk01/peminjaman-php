<?php
/**
 * includes/book_filter.php
 * Fungsi bersama untuk membangun query WHERE/ORDER berdasarkan
 * parameter pencarian (q), filter kategori, dan sorting tahun.
 * Dipakai oleh: data_json.php, export_excel.php, export_pdf.php
 * supaya "Export sesuai hasil pencarian" & "Cetak laporan per kategori"
 * selalu konsisten dengan tabel yang sedang dilihat admin.
 */

function build_book_filter(string $q, string $kategori, string $sort): array
{
    $sql    = "SELECT id, kode_buku, judul, penulis, kategori, tahun_terbit, penerbit, sampul FROM books WHERE 1=1";
    $params = [];

    if ($q !== '') {
        $sql .= " AND (
            kode_buku LIKE :q_kode
            OR judul LIKE :q_judul
            OR penulis LIKE :q_penulis
            OR kategori LIKE :q_kategori
        )";
        $search = "%{$q}%";
        $params[':q_kode'] = $search;
        $params[':q_judul'] = $search;
        $params[':q_penulis'] = $search;
        $params[':q_kategori'] = $search;
    }

    if ($kategori !== '') {
        $sql .= " AND kategori = :kategori";
        $params[':kategori'] = $kategori;
    }

    if ($sort === 'tahun_asc') {
        $sql .= " ORDER BY tahun_terbit ASC";
    } elseif ($sort === 'tahun_desc') {
        $sql .= " ORDER BY tahun_terbit DESC";
    } else {
        $sql .= " ORDER BY id ASC";
    }

    return [$sql, $params];
}
