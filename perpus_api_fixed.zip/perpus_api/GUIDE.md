# PANDUAN PROJECT — Aplikasi Data Buku Perpustakaan (perpus_api)

## 1. Cara Menjalankan di XAMPP

1. Copy seluruh folder `perpus_api` ke `C:\xampp\htdocs\`.
2. Jalankan XAMPP → Start **Apache** dan **MySQL**.
3. Buka `http://localhost/phpmyadmin` → tab SQL → jalankan isi `sql/schema.sql`
   (file ini sudah membuat database, tabel `admins` + `books` dengan kolom
   `sampul` untuk foto sampul, serta 10 data contoh dan 1 akun admin).
4. Pastikan folder `assets/img/covers/` bisa ditulis oleh web server
   (permission write) — di situ foto sampul yang diunggah akan disimpan.
5. Buka `http://localhost/perpus_api/` → akan diarahkan ke halaman Login.
6. Login: `admin` / `admin123`.

## 2. Struktur File

```
perpus_api/
├── index.php            entry point (redirect login/dashboard)
├── login.php            halaman login
├── logout.php           proses logout
├── auth.php             helper cek session (dipakai semua halaman admin)
├── koneksi.php          koneksi PDO ke database
├── dashboard.php        statistik + grafik kategori
├── data_json.php        API JSON data buku (search, filter, sort, pagination)
├── data_buku.php        halaman tabel data buku + modal tambah/edit
├── simpan_buku.php      endpoint AJAX simpan (insert/update) + upload sampul
├── get_buku.php         endpoint AJAX ambil 1 data buku (untuk modal edit)
├── hapus.php            endpoint AJAX hapus buku (+ hapus file sampul)
├── tambah.php           redirect kompatibilitas -> modal tambah
├── edit.php             redirect kompatibilitas -> modal edit
├── export_excel.php     export ke .xls, mendukung filter pencarian/kategori
├── export_pdf.php       laporan cetak PDF, mendukung filter per kategori
├── includes/book_filter.php   query builder search/filter/sort bersama
├── partials/sidebar.php       komponen sidebar + tombol dark mode
├── partials/theme-init.php    skrip kecil supaya tema gelap tidak "kedip"
├── assets/css/style.css       styling tambahan (di atas Bootstrap 5)
├── assets/js/app.js           logic fetch, search, filter, sort, pagination, modal, hapus
├── assets/img/covers/         folder penyimpanan foto sampul yang diunggah
└── sql/schema.sql             skrip database (tabel + data contoh)
```

## 3. Daftar Fitur

| Fitur | Keterangan |
|---|---|
| Pencarian buku | Kotak cari di atas tabel, live search (debounce) via `data_json.php?q=` |
| Filter kategori | Dropdown kategori, terhubung ke `data_json.php?kategori=` |
| Sorting tahun | Dropdown urutkan tahun terbit naik/turun |
| Pagination | Tabel dibagi per halaman (5/10/25 baris), navigasi di bawah tabel |
| Statistik grafik | Dashboard menampilkan 4 kartu statistik + grafik batang Chart.js |
| Tampilan responsive | Layout menyesuaikan di layar kecil (sidebar collapsible, grid kartu) |
| Bootstrap | Bootstrap 5.3 dipakai untuk grid, tombol, form, modal, pagination |
| SweetAlert | Konfirmasi hapus & notifikasi berhasil/gagal pakai SweetAlert2 |
| Modal form | Tambah & edit buku memakai modal Bootstrap (tanpa pindah halaman) |
| Validasi input | Validasi client-side (Bootstrap `required`, tahun, ukuran file) & server-side (PHP) |
| Foto sampul buku | Upload foto sampul (jpg/png/webp, maks 2MB) saat tambah/edit, tampil di tabel |
| Dark mode | Tombol di sidebar untuk beralih mode terang/gelap, tersimpan di `localStorage` |
| Cetak laporan per kategori | `export_pdf.php?kategori=...` — tombol "Cetak Laporan" di halaman Data Buku otomatis membawa kategori yang sedang difilter |
| Export sesuai hasil pencarian | `export_excel.php` & `export_pdf.php` menerima parameter `q`/`kategori`/`sort` yang sama dengan tabel, sehingga hasil export selalu sesuai apa yang sedang ditampilkan |

## 4. Checklist Pengujian

| No | Pengujian | Langkah | Hasil Diharapkan |
|----|-----------|---------|-------------------|
| 1 | Database dibuat | Jalankan `sql/schema.sql` | Database `perpus_api` muncul di phpMyAdmin |
| 2 | Tabel books | Cek phpMyAdmin | Tabel `books` dengan 10 baris + kolom `sampul` |
| 3 | Tabel admins | Cek phpMyAdmin | Tabel `admins` dengan 1 baris |
| 4 | Login berhasil | Login admin/admin123 | Masuk ke dashboard.php |
| 5 | Login salah | Login dengan password salah | Pesan error muncul, tetap di login.php |
| 6 | Proteksi halaman | Buka dashboard.php tanpa login (browser lain) | Diarahkan ke login.php |
| 7 | Statistik dari DB | Lihat dashboard | 4 angka sesuai isi database |
| 8 | API JSON | Buka data_json.php | Output JSON valid berisi `data` + `pagination` |
| 9 | Fetch API | Buka data_buku.php | Tabel terisi otomatis tanpa reload manual |
| 10 | Search/filter/sort | Ketik di kolom cari, pilih kategori, pilih urutan | Tabel ter-update sesuai filter, halaman kembali ke 1 |
| 11 | Pagination | Ubah jumlah per halaman / klik nomor halaman | Data & tombol halaman berubah sesuai |
| 12 | Tambah data (modal) | Klik "+ Tambah Buku", isi form, unggah sampul | Modal tertutup, data baru muncul di tabel |
| 13 | Validasi duplikat | Tambah kode_buku yang sama | Muncul pesan error di field kode_buku |
| 14 | Edit data (modal) | Klik "Edit" pada salah satu baris | Modal terisi data lama, perubahan tersimpan |
| 15 | Hapus data | Klik Hapus + konfirmasi SweetAlert | Data hilang dari tabel |
| 16 | Dark mode | Klik tombol "Mode Gelap" di sidebar | Tampilan berubah gelap, tetap gelap setelah pindah halaman/reload |
| 17 | Export Excel (filtered) | Cari/filter data, klik "Export Excel" | File `.xls` berisi hanya data hasil filter |
| 18 | Cetak laporan per kategori | Pilih kategori, klik "Cetak Laporan" | Halaman cetak menampilkan hanya buku kategori tsb, judul menyebut nama kategori |
| 19 | Logout | Klik Logout | Session hilang, kembali ke login.php |
| 20 | Tidak ada error | Cek semua halaman | Tidak ada error PHP/SQL/JS di console |

## 5. Upgrade Export (Opsional, pakai Composer)

Jika ingin file `.xlsx` biner asli dan PDF asli tanpa dialog print browser:

```bash
cd C:\xampp\htdocs\perpus_api
composer require phpoffice/phpspreadsheet
composer require dompdf/dompdf
```

Setelah itu, tambahkan `require 'vendor/autoload.php';` di baris atas `export_excel.php` / `export_pdf.php`,
lalu ganti isi fungsinya menggunakan class `Spreadsheet`/`Xlsx` (PhpSpreadsheet) dan `Dompdf\Dompdf` (Dompdf)
sesuai dokumentasi resmi masing-masing. Query filter (`includes/book_filter.php`) tetap sama persis —
hanya bagian "cara menulis file output" yang berubah.

## 6. Screenshot yang Harus Diambil

- Halaman Login
- Dashboard (statistik + grafik)
- Data Buku (tabel hasil fetch + pagination)
- Modal Tambah / Edit Buku (dengan foto sampul)
- Mode gelap (dark mode) aktif
- Tampilan JSON API (data_json.php)
- Hasil file Excel terbuka (hasil filter kategori/pencarian)
- Hasil file PDF laporan per kategori

## 7. Nama Project untuk Pengumpulan

Format: `NAMA_KELAS_PERPUSAPI` (contoh: `BUDI_XIIRPL2_PERPUSAPI`)
Zip seluruh folder lalu upload ke GitHub sesuai instruksi jobsheet.

## 8. Refleksi (contoh poin jawaban singkat, kembangkan sendiri)

1. API menjadi jembatan antara database dan tampilan agar data bisa diakses lewat JavaScript/Fetch tanpa reload halaman.
2. JSON adalah format pertukaran data ringan yang mudah dibaca JavaScript maupun bahasa lain.
3. Data diambil dari database (bukan ditulis manual) agar selalu sinkron dan akurat saat ada perubahan.
4. Fetch API dipakai untuk mengambil data dari server secara asynchronous di sisi client.
5. Login Admin membatasi akses agar hanya admin yang bisa mengelola data.
6. Session PHP menyimpan status login pengguna selama browser masih terbuka.
7. Statistik dihitung langsung dari query agregat (COUNT, MAX) terhadap tabel books.
8. Create=tambah data (modal), Read=tampilkan data (tabel+pagination), Update=ubah data (modal), Delete=hapus data.
9. Modal form membuat proses tambah/edit lebih cepat karena admin tidak perlu berpindah halaman.
10. Pagination penting agar tabel tetap ringan & mudah dibaca meski data buku sangat banyak.
11. Export Excel/PDF yang mengikuti filter aktif memudahkan admin membuat laporan spesifik (misal per kategori) tanpa mengedit ulang data.
12. Dark mode disimpan di localStorage supaya preferensi tampilan admin tetap konsisten di semua halaman.
13–14. (isi sesuai pengalaman pribadi saat mengerjakan)
