<?php
/**
 * export_excel.php
 * Export data buku ke file Excel (.xls) TANPA library tambahan.
 * Teknik: mengirim tabel HTML dengan Content-Type Excel — dibuka
 * normal oleh Microsoft Excel / LibreOffice Calc / Google Sheets.
 *
 * Mendukung filter yang sama dengan tabel data buku (GET params):
 *   q         cari kode/judul/penulis/kategori
 *   kategori  filter kategori
 *   sort      tahun_asc | tahun_desc
 * Sehingga "Export Excel" dari halaman Data Buku otomatis mengikuti
 * hasil pencarian/filter yang sedang aktif.
 *
 * Ingin file .xlsx "asli" (binary)? Lihat catatan PhpSpreadsheet
 * di GUIDE.md bagian "Upgrade Export" — file ini tetap kompatibel,
 * tinggal ganti isinya sesuai contoh di sana.
 */

require 'auth.php';
require_login();
require 'koneksi.php';
require 'includes/book_filter.php';

$q        = trim($_GET['q'] ?? '');
$kategori = trim($_GET['kategori'] ?? '');
$sort     = $_GET['sort'] ?? '';

[$sql, $params] = build_book_filter($q, $kategori, $sort);
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

$fileName = 'data_buku';
if ($kategori !== '') $fileName .= '_' . preg_replace('/[^a-zA-Z0-9_-]/', '', $kategori);
if ($q !== '')        $fileName .= '_cari';
$fileName .= '.xls';

header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $fileName . '"');
header('Pragma: no-cache');
header('Expires: 0');

echo "<table border='1'>";

$keteranganFilter = [];
if ($kategori !== '') $keteranganFilter[] = 'Kategori: ' . htmlspecialchars($kategori);
if ($q !== '')        $keteranganFilter[] = 'Kata kunci: ' . htmlspecialchars($q);
if (!empty($keteranganFilter)) {
    echo '<tr><td colspan="7"><b>Filter aktif — ' . implode(' | ', $keteranganFilter) . '</b></td></tr>';
}

echo "<tr>
        <th>No/ID</th><th>Kode Buku</th><th>Judul</th><th>Penulis</th>
        <th>Kategori</th><th>Tahun Terbit</th><th>Penerbit</th>
      </tr>";

foreach ($books as $i => $b) {
    echo '<tr>';
    echo '<td>' . ($i + 1) . '</td>';
    echo '<td>' . htmlspecialchars($b['kode_buku']) . '</td>';
    echo '<td>' . htmlspecialchars($b['judul']) . '</td>';
    echo '<td>' . htmlspecialchars($b['penulis']) . '</td>';
    echo '<td>' . htmlspecialchars($b['kategori']) . '</td>';
    echo '<td>' . htmlspecialchars($b['tahun_terbit']) . '</td>';
    echo '<td>' . htmlspecialchars($b['penerbit']) . '</td>';
    echo '</tr>';
}

echo "</table>";
