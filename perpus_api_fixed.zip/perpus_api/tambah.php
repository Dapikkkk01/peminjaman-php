<?php
/**
 * tambah.php
 * Fitur "Tambah Buku" sekarang menggunakan MODAL FORM di data_buku.php
 * (lihat tombol "+ Tambah Buku"). File ini dipertahankan hanya supaya
 * tautan lama tetap berfungsi, dengan mengarahkan ke modal tersebut.
 */
require 'auth.php';
require_login();
header('Location: data_buku.php?aksi=tambah');
exit;
